package com.kafka.consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
